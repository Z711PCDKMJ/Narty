﻿using System.ComponentModel.DataAnnotations;

namespace Narty.Domain.Entities {

    public class ShippingDetails {
        [Required(ErrorMessage = "Proszę podać imię i nazwisko.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Proszę podać datę początkową.")]
        public string Line1 { get; set; }
        [Required(ErrorMessage = "Proszę podać datę końcową")]
        public string Line2 { get; set; }
        [Required(ErrorMessage = "Proszę podać ulicę")]
        public string Line3 { get; set; }

        [Required(ErrorMessage = "Proszę podać nazwę miasto.")]
        public string City { get; set; }

        [Required(ErrorMessage = "Proszę podać nazwę województwa.")]
        public string State { get; set; }

        public string Zip { get; set; }

        [Required(ErrorMessage = "Proszę podać nazwę kraju.")]
        public string Country { get; set; }

        
    }
}